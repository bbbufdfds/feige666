<template>
	<view class="container">
		<Itable :column="column" :list="list" />
	</view>
</template>

<script>
	import { rechargelog } from "@/api/finance.js"
	export default {
		data() {
			return {
				list: [],
				page: 1,
				data:{},
				column:[
					{
						title: "订单号",
						prop: "ordernumber",
					},
					{
						title: "充值金额",
						prop: "amount",
					},
					{
						title: "充值方式",
						prop: "type",
					},
					{
						title: "订单状态",
						prop: "status",
						format: function(item){
							return item.status == 0?"未支付":item.status == 1?"已支付":"已取消"
						}
					}
				]
			}
		},
		onLoad() {
			this.getList()
		},
		
		onReachBottom() {
			this.page = this.page + 1
			this.getList()
		},
		methods:{
			getList(){
				let that = this
				uni.showLoading({
					title: '加载中...',
					mask: true
				});
				rechargelog({
					page: this.page
				}).then(res=>{
					if(res.status == 0){
						const { data } = res.data;
						if(data.length > 0){
							that.list = that.list.concat(data)
						}else{
							that.page = that.page - 1
						}
						that.data = res.show
					}
				})
			}
		}
	}
</script>

<style lang="scss">
	.container{
		width: 95%;
		margin: 0 auto;
		
	}
</style>